from tkinter import Tk, Label, Entry, Frame, Button, messagebox

class VentanaBase(Tk):
    def __init__(self, titulo, siguiente_ventana=None):
        super().__init__()
        self.title(titulo)
        self.state("zoomed")
        self.siguiente = siguiente_ventana
        
        self.frame = Frame(self)
        self.frame.pack(pady=20)
        
        self.lblTitulo = Label(self, text=titulo, font=("Arial", 14, "bold"))
        self.lblTitulo.place(x=400, y=10, width=300, height=30)
        
        self.btnGuardar = Button(self, text="Guardar y Continuar", command=self.guardar_y_continuar)
        self.btnGuardar.place(x=400, y=500, width=200, height=30)
        
        self.entradas = {}

    def guardar_y_continuar(self):
        messagebox.showinfo("Éxito", "Datos guardados correctamente")
        self.abrir_siguiente_ventana()
    
    def abrir_siguiente_ventana(self):
        self.destroy()
        if self.siguiente:
            ventana_siguiente = self.siguiente()
            ventana_siguiente.mainloop()
        else:
            messagebox.showinfo("Fin", "Has completado todos los formularios")

class VentanaCategorias(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Catálogo de Categorías - Abarrotes Wallis", siguiente_ventana)
        
        lblIdcategoria = Label(self, text="ID Categoría")
        lblIdcategoria.place(x=20, y=50, width=100, height=20)
        self.entradas["id_categoria"] = Entry(self, bg="pink")
        self.entradas["id_categoria"].place(x=130, y=50, width=200, height=20)
        
        lblNombre = Label(self, text="Nombre")
        lblNombre.place(x=20, y=90, width=100, height=20)
        self.entradas["nombre"] = Entry(self, bg="pink")
        self.entradas["nombre"].place(x=130, y=90, width=200, height=20)
    
    def guardar_y_continuar(self):
        if not self.entradas["id_categoria"].get() or not self.entradas["nombre"].get():
            messagebox.showerror("Error", "Todos los campos son obligatorios")
            return
        
        messagebox.showinfo("Éxito", "Categoría guardada correctamente")
        self.abrir_siguiente_ventana()

class VentanaProveedores(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Gestión de Proveedores - Abarrotes Wallis", siguiente_ventana)
        
        lblIdProveedor = Label(self, text="ID Proveedor")
        lblIdProveedor.place(x=20, y=50, width=100, height=20)
        self.entradas["id_proveedor"] = Entry(self, bg="lightgreen")
        self.entradas["id_proveedor"].place(x=130, y=50, width=200, height=20)
        
        lblNombre = Label(self, text="Nombre")
        lblNombre.place(x=20, y=90, width=100, height=20)
        self.entradas["nombre"] = Entry(self, bg="lightgreen")
        self.entradas["nombre"].place(x=130, y=90, width=200, height=20)
        
        lblNumCelular = Label(self, text="Número Celular")
        lblNumCelular.place(x=20, y=130, width=100, height=20)
        self.entradas["num_celular"] = Entry(self, bg="lightgreen")
        self.entradas["num_celular"].place(x=130, y=130, width=200, height=20)
        
        lblContacto = Label(self, text="Contacto")
        lblContacto.place(x=20, y=170, width=100, height=20)
        self.entradas["contacto"] = Entry(self, bg="lightgreen")
        self.entradas["contacto"].place(x=130, y=170, width=300, height=20)
    
    def guardar_y_continuar(self):
        if not self.entradas["id_proveedor"].get() or not self.entradas["nombre"].get():
            messagebox.showerror("Error", "ID y Nombre son obligatorios")
            return
        
        messagebox.showinfo("Éxito", "Proveedor guardado correctamente")
        self.abrir_siguiente_ventana()

class VentanaProductos(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Productos - Abarrotes Wallis", siguiente_ventana)
        
        lblCodigo = Label(self, text="Código")
        lblCodigo.place(x=20, y=50, width=100, height=20)
        self.entradas["codigo"] = Entry(self, bg="lightblue")
        self.entradas["codigo"].place(x=130, y=50, width=200, height=20)
        
        lblNombre = Label(self, text="Nombre")
        lblNombre.place(x=20, y=90, width=100, height=20)
        self.entradas["nombre"] = Entry(self, bg="lightblue")
        self.entradas["nombre"].place(x=130, y=90, width=200, height=20)
        
        lblPrecio = Label(self, text="Precio")
        lblPrecio.place(x=20, y=130, width=100, height=20)
        self.entradas["precio"] = Entry(self, bg="lightblue")
        self.entradas["precio"].place(x=130, y=130, width=200, height=20)
        
        lblCosto = Label(self, text="Costo")
        lblCosto.place(x=20, y=170, width=100, height=20)
        self.entradas["costo"] = Entry(self, bg="lightblue")
        self.entradas["costo"].place(x=130, y=170, width=200, height=20)
        
        lblExistencias = Label(self, text="Existencias")
        lblExistencias.place(x=20, y=210, width=100, height=20)
        self.entradas["existencias"] = Entry(self, bg="lightblue")
        self.entradas["existencias"].place(x=130, y=210, width=200, height=20)
        
        lblIdCategoria = Label(self, text="ID Categoría")
        lblIdCategoria.place(x=20, y=250, width=100, height=20)
        self.entradas["id_categoria"] = Entry(self, bg="lightblue")
        self.entradas["id_categoria"].place(x=130, y=250, width=200, height=20)
        
        lblIdProveedor = Label(self, text="ID Proveedor")
        lblIdProveedor.place(x=20, y=290, width=100, height=20)
        self.entradas["id_proveedor"] = Entry(self, bg="lightblue")
        self.entradas["id_proveedor"].place(x=130, y=290, width=200, height=20)
        
        lblIdUnidad = Label(self, text="ID Unidad")
        lblIdUnidad.place(x=20, y=330, width=100, height=20)
        self.entradas["id_unidad"] = Entry(self, bg="lightblue")
        self.entradas["id_unidad"].place(x=130, y=330, width=200, height=20)
        
        lblFechaVenc = Label(self, text="Fecha Vencimiento")
        lblFechaVenc.place(x=20, y=370, width=110, height=20)
        self.entradas["fecha_vencimiento"] = Entry(self, bg="lightblue")
        self.entradas["fecha_vencimiento"].place(x=140, y=370, width=190, height=20)
    
    def guardar_y_continuar(self):
        try:
            if not self.entradas["codigo"].get() or not self.entradas["nombre"].get():
                messagebox.showerror("Error", "Código y Nombre son obligatorios")
                return
            
            if self.entradas["precio"].get():
                float(self.entradas["precio"].get())
            if self.entradas["costo"].get():
                float(self.entradas["costo"].get())
            
            messagebox.showinfo("Éxito", "Producto guardado correctamente")
            self.abrir_siguiente_ventana()
        except ValueError:
            messagebox.showerror("Error", "Los campos numéricos deben tener valores válidos")

class VentanaCompras(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Compras - Abarrotes Wallis", siguiente_ventana)
        
        lblIdCompra = Label(self, text="ID Compra")
        lblIdCompra.place(x=20, y=50, width=100, height=20)
        self.entradas["id_compra"] = Entry(self, bg="lightyellow")
        self.entradas["id_compra"].place(x=130, y=50, width=200, height=20)
        
        lblIdProveedor = Label(self, text="ID Proveedor")
        lblIdProveedor.place(x=20, y=90, width=100, height=20)
        self.entradas["id_proveedor"] = Entry(self, bg="lightyellow")
        self.entradas["id_proveedor"].place(x=130, y=90, width=200, height=20)
        
        lblFecha = Label(self, text="Fecha")
        lblFecha.place(x=20, y=130, width=100, height=20)
        self.entradas["fecha"] = Entry(self, bg="lightyellow")
        self.entradas["fecha"].place(x=130, y=130, width=200, height=20)
        
        lblImporte = Label(self, text="Importe")
        lblImporte.place(x=20, y=170, width=100, height=20)
        self.entradas["importe"] = Entry(self, bg="lightyellow")
        self.entradas["importe"].place(x=130, y=170, width=200, height=20)
    
    def guardar_y_continuar(self):
        try:
            if not self.entradas["id_compra"].get() or not self.entradas["id_proveedor"].get():
                messagebox.showerror("Error", "ID Compra e ID Proveedor son obligatorios")
                return
            
            if self.entradas["importe"].get():
                float(self.entradas["importe"].get())
            
            messagebox.showinfo("Éxito", "Compra registrada correctamente")
            self.abrir_siguiente_ventana()
        except ValueError:
            messagebox.showerror("Error", "El importe debe ser un número válido")

class VentanaDetalleCompra(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Detalle de Compra - Abarrotes Wallis", siguiente_ventana)
        
        lblIdCompra = Label(self, text="ID Compra")
        lblIdCompra.place(x=20, y=50, width=100, height=20)
        self.entradas["id_compra"] = Entry(self, bg="lavender")
        self.entradas["id_compra"].place(x=130, y=50, width=200, height=20)
        
        lblCodigo = Label(self, text="Código")
        lblCodigo.place(x=20, y=90, width=100, height=20)
        self.entradas["codigo"] = Entry(self, bg="lavender")
        self.entradas["codigo"].place(x=130, y=90, width=200, height=20)
        
        lblCantidad = Label(self, text="Cantidad")
        lblCantidad.place(x=20, y=130, width=100, height=20)
        self.entradas["cantidad"] = Entry(self, bg="lavender")
        self.entradas["cantidad"].place(x=130, y=130, width=200, height=20)
        
        lblPrecio = Label(self, text="Precio")
        lblPrecio.place(x=20, y=170, width=100, height=20)
        self.entradas["precio"] = Entry(self, bg="lavender")
        self.entradas["precio"].place(x=130, y=170, width=200, height=20)
        
        lblCosto = Label(self, text="Costo")
        lblCosto.place(x=20, y=210, width=100, height=20)
        self.entradas["costo"] = Entry(self, bg="lavender")
        self.entradas["costo"].place(x=130, y=210, width=200, height=20)
    
    def guardar_y_continuar(self):
        try:
            if not self.entradas["id_compra"].get() or not self.entradas["codigo"].get():
                messagebox.showerror("Error", "ID Compra y Código son obligatorios")
                return
            
            if self.entradas["cantidad"].get():
                int(self.entradas["cantidad"].get())
            if self.entradas["precio"].get():
                float(self.entradas["precio"].get())
            if self.entradas["costo"].get():
                float(self.entradas["costo"].get())
            
            messagebox.showinfo("Éxito", "Detalle de compra guardado correctamente")
            self.abrir_siguiente_ventana()
        except ValueError:
            messagebox.showerror("Error", "Los campos numéricos deben tener valores válidos")

class VentanaEmpleados(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Empleados - Abarrotes Wallis", siguiente_ventana)
        
        lblIdEmpleado = Label(self, text="ID Empleado")
        lblIdEmpleado.place(x=20, y=50, width=100, height=20)
        self.entradas["id_empleado"] = Entry(self, bg="paleturquoise")
        self.entradas["id_empleado"].place(x=130, y=50, width=200, height=20)
        
        lblNombre = Label(self, text="Nombre")
        lblNombre.place(x=20, y=90, width=100, height=20)
        self.entradas["nombre"] = Entry(self, bg="paleturquoise")
        self.entradas["nombre"].place(x=130, y=90, width=200, height=20)
    
        lblPuesto = Label(self, text="Puesto")
        lblPuesto.place(x=20, y=130, width=100, height=20)
        self.entradas["puesto"] = Entry(self, bg="paleturquoise")
        self.entradas["puesto"].place(x=130, y=130, width=200, height=20)
        
        lblNumCelular = Label(self, text="Número Celular")
        lblNumCelular.place(x=20, y=170, width=100, height=20)
        self.entradas["num_celular"] = Entry(self, bg="paleturquoise")
        self.entradas["num_celular"].place(x=130, y=170, width=200, height=20)
    
    def guardar_y_continuar(self):
        if not self.entradas["id_empleado"].get() or not self.entradas["nombre"].get():
            messagebox.showerror("Error", "ID Empleado y Nombre son obligatorios")
            return
        
        messagebox.showinfo("Éxito", "Empleado registrado correctamente")
        self.abrir_siguiente_ventana()

class VentanaClientes(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Clientes - Abarrotes Wallis", siguiente_ventana)

        lblIdCliente = Label(self, text="ID Cliente")
        lblIdCliente.place(x=20, y=50, width=100, height=20)
        self.entradas["id_cliente"] = Entry(self, bg="peachpuff")
        self.entradas["id_cliente"].place(x=130, y=50, width=200, height=20)
        
        lblNombre = Label(self, text="Nombre")
        lblNombre.place(x=20, y=90, width=100, height=20)
        self.entradas["nombre"] = Entry(self, bg="peachpuff")
        self.entradas["nombre"].place(x=130, y=90, width=200, height=20)

        lblTelefono = Label(self, text="Teléfono")
        lblTelefono.place(x=20, y=130, width=100, height=20)
        self.entradas["telefono"] = Entry(self, bg="peachpuff")
        self.entradas["telefono"].place(x=130, y=130, width=200, height=20)

        lblDireccion = Label(self, text="Dirección")
        lblDireccion.place(x=20, y=170, width=100, height=20)
        self.entradas["direccion"] = Entry(self, bg="peachpuff")
        self.entradas["direccion"].place(x=130, y=170, width=300, height=20)
    
    def guardar_y_continuar(self):
        if not self.entradas["id_cliente"].get() or not self.entradas["nombre"].get():
            messagebox.showerror("Error", "ID Cliente y Nombre son obligatorios")
            return
        
        messagebox.showinfo("Éxito", "Cliente registrado correctamente")
        self.abrir_siguiente_ventana()

class VentanaVentas(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Ventas - Abarrotes Wallis", siguiente_ventana)
        
        lblIdVenta = Label(self, text="ID Venta")
        lblIdVenta.place(x=20, y=50, width=100, height=20)
        self.entradas["id_venta"] = Entry(self, bg="plum")
        self.entradas["id_venta"].place(x=130, y=50, width=200, height=20)
        
        lblFecha = Label(self, text="Fecha")
        lblFecha.place(x=20, y=90, width=100, height=20)
        self.entradas["fecha"] = Entry(self, bg="plum")
        self.entradas["fecha"].place(x=130, y=90, width=200, height=20)
        
        lblImporte = Label(self, text="Importe")
        lblImporte.place(x=20, y=130, width=100, height=20)
        self.entradas["importe"] = Entry(self, bg="plum")
        self.entradas["importe"].place(x=130, y=130, width=200, height=20)
        
        lblIdCliente = Label(self, text="ID Cliente")
        lblIdCliente.place(x=20, y=170, width=100, height=20)
        self.entradas["id_cliente"] = Entry(self, bg="plum")
        self.entradas["id_cliente"].place(x=130, y=170, width=200, height=20)
        
        lblIdEmpleado = Label(self, text="ID Empleado")
        lblIdEmpleado.place(x=20, y=210, width=100, height=20)
        self.entradas["id_empleado"] = Entry(self, bg="plum")
        self.entradas["id_empleado"].place(x=130, y=210, width=200, height=20)
    
    def guardar_y_continuar(self):
        try:
            if not self.entradas["id_venta"].get() or not self.entradas["fecha"].get():
                messagebox.showerror("Error", "ID Venta y Fecha son obligatorios")
                return
            if self.entradas["importe"].get():
                float(self.entradas["importe"].get())
            
            messagebox.showinfo("Éxito", "Venta registrada correctamente")
            self.abrir_siguiente_ventana()
        except ValueError:
            messagebox.showerror("Error", "El importe debe ser un número válido")

class VentanaDetalleVenta(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Detalle de Venta - Abarrotes Wallis", siguiente_ventana)
        
        lblIdVenta = Label(self, text="ID Venta")
        lblIdVenta.place(x=20, y=50, width=100, height=20)
        self.entradas["id_venta"] = Entry(self, bg="mistyrose")
        self.entradas["id_venta"].place(x=130, y=50, width=200, height=20)
        
        lblCodigo = Label(self, text="Código Producto")
        lblCodigo.place(x=20, y=90, width=100, height=20)
        self.entradas["codigo"] = Entry(self, bg="mistyrose")
        self.entradas["codigo"].place(x=130, y=90, width=200, height=20)
        
        lblCantidad = Label(self, text="Cantidad")
        lblCantidad.place(x=20, y=130, width=100, height=20)
        self.entradas["cantidad"] = Entry(self, bg="mistyrose")
        self.entradas["cantidad"].place(x=130, y=130, width=200, height=20)
        
        lblPrecio = Label(self, text="Precio")
        lblPrecio.place(x=20, y=170, width=100, height=20)
        self.entradas["precio"] = Entry(self, bg="mistyrose")
        self.entradas["precio"].place(x=130, y=170, width=200, height=20)
        
        lblDescuento = Label(self, text="Descuento")
        lblDescuento.place(x=20, y=210, width=100, height=20)
        self.entradas["descuento"] = Entry(self, bg="mistyrose")
        self.entradas["descuento"].place(x=130, y=210, width=200, height=20)
    
    def guardar_y_continuar(self):
        try:
            if not self.entradas["id_venta"].get() or not self.entradas["codigo"].get():
                messagebox.showerror("Error", "ID Venta y Código son obligatorios")
                return
            
            if self.entradas["cantidad"].get():
                int(self.entradas["cantidad"].get())
            if self.entradas["precio"].get():
                float(self.entradas["precio"].get())
            if self.entradas["descuento"].get():
                float(self.entradas["descuento"].get())
            
            messagebox.showinfo("Éxito", "Detalle de venta guardado correctamente")
            self.abrir_siguiente_ventana()
        except ValueError:
            messagebox.showerror("Error", "Los campos numéricos deben tener valores válidos")

def main():
    app = VentanaCategorias(
              lambda: VentanaProveedores(
                  lambda: VentanaProductos(
                      lambda: VentanaCompras(
                          lambda: VentanaDetalleCompra(
                              lambda: VentanaEmpleados(
                                  lambda: VentanaClientes(
                                      lambda: VentanaVentas(
                                          lambda: VentanaDetalleVenta(None)
                                      )
                                  )
                              )
                          )
                      )
                  )
              )
          )
    app.mainloop()

if __name__ == "__main__":
    main()