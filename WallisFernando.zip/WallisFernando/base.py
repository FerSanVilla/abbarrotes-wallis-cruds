from tkinter import Tk, Label, Entry, Frame, Button, messagebox

class VentanaBase(Tk):
    def __init__(self, titulo, siguiente_ventana=None):
        super().__init__()
        self.title(titulo)
        self.state("zoomed")
        self.siguiente = siguiente_ventana
        
        self.frame = Frame(self)
        self.frame.pack(pady=20)
        
        self.lblTitulo = Label(self, text=titulo, font=("Arial", 14, "bold"))
        self.lblTitulo.place(x=400, y=10, width=300, height=30)
        
        self.btnGuardar = Button(self, text="Guardar y Continuar", command=self.guardar_y_continuar)
        self.btnGuardar.place(x=400, y=500, width=200, height=30)
        
        self.entradas = {}

    def guardar_y_continuar(self):
        messagebox.showinfo("Éxito", "Datos guardados correctamente")
        self.abrir_siguiente_ventana()
    
    def abrir_siguiente_ventana(self):
        self.destroy()
        if self.siguiente:
            ventana_siguiente = self.siguiente()
            ventana_siguiente.mainloop()
        else:
            messagebox.showinfo("Fin", "Has completado todos los formularios")
