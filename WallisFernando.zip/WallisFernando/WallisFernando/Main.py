from categorias import VentanaCategorias
from proveedores import VentanaProveedores
from productos import VentanaProductos
from compras import VentanaCompras
from empleados import VentanaEmpleados
from clientes import VentanaClientes
from ventas import VentanaVentas

def main():
    app = VentanaCategorias(
        lambda: VentanaProveedores(
            lambda: VentanaProductos(
                lambda: VentanaCompras(
                    lambda: VentanaEmpleados(
                        lambda: VentanaClientes(
                            lambda: VentanaVentas(None)
                        )
                    )
                )
            )
        )
    )
    app.mainloop()

if __name__ == "__main__":
    main()
