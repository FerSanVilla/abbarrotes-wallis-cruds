from tkinter import Label, Entry, messagebox
from base import VentanaBase

class VentanaProductos(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Productos - Abarrotes Wallis", siguiente_ventana)
        
        campos = [
            ("codigo", "Código"),
            ("nombre", "Nombre"),
            ("precio", "Precio"),
            ("costo", "Costo"),
            ("existencias", "Existencias"),
            ("id_categoria", "ID Categoría"),
            ("id_proveedor", "ID Proveedor"),
            ("id_unidad", "ID Unidad"),
            ("fecha_vencimiento", "Fecha Vencimiento")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self, text=texto)
            lbl.place(x=20, y=50 + i*40, width=120, height=20)
            self.entradas[clave] = Entry(self, bg="lightblue")
            self.entradas[clave].place(x=150, y=50 + i*40, width=200, height=20)
    
    def guardar_y_continuar(self):
        try:
            if not self.entradas["codigo"].get() or not self.entradas["nombre"].get():
                messagebox.showerror("Error", "Código y Nombre son obligatorios")
                return
            if self.entradas["precio"].get():
                float(self.entradas["precio"].get())
            if self.entradas["costo"].get():
                float(self.entradas["costo"].get())
            messagebox.showinfo("Éxito", "Producto guardado correctamente")
            self.abrir_siguiente_ventana()
        except ValueError:
            messagebox.showerror("Error", "Los campos numéricos deben tener valores válidos")
