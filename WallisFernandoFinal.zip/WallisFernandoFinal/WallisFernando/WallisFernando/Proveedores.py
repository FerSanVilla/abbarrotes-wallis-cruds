from tkinter import Label, Entry, messagebox
from base import VentanaBase

class VentanaProveedores(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Gestión de Proveedores - Abarrotes Wallis", siguiente_ventana)
        
        lblIdProveedor = Label(self, text="ID Proveedor")
        lblIdProveedor.place(x=20, y=50, width=100, height=20)
        self.entradas["id_proveedor"] = Entry(self, bg="lightgreen")
        self.entradas["id_proveedor"].place(x=130, y=50, width=200, height=20)
        
        lblNombre = Label(self, text="Nombre")
        lblNombre.place(x=20, y=90, width=100, height=20)
        self.entradas["nombre"] = Entry(self, bg="lightgreen")
        self.entradas["nombre"].place(x=130, y=90, width=200, height=20)
        
        lblNumCelular = Label(self, text="Número Celular")
        lblNumCelular.place(x=20, y=130, width=100, height=20)
        self.entradas["num_celular"] = Entry(self, bg="lightgreen")
        self.entradas["num_celular"].place(x=130, y=130, width=200, height=20)
        
        lblContacto = Label(self, text="Contacto")
        lblContacto.place(x=20, y=170, width=100, height=20)
        self.entradas["contacto"] = Entry(self, bg="lightgreen")
        self.entradas["contacto"].place(x=130, y=170, width=300, height=20)
    
    def guardar_y_continuar(self):
        if not self.entradas["id_proveedor"].get() or not self.entradas["nombre"].get():
            messagebox.showerror("Error", "ID y Nombre son obligatorios")
            return
        
        messagebox.showinfo("Éxito", "Proveedor guardado correctamente")
        self.abrir_siguiente_ventana()
