from Categorias import VentanaCategorias
from Proveedores import VentanaProveedores
from Productos import VentanaProductos
from compras import VentanaCompras
from Empleados import VentanaEmpleados
from Clientes import VentanaVerClientes
from Ventas import VentanaVentas

def main():
    app = VentanaCategorias(
        lambda: VentanaProveedores(
            lambda: VentanaProductos(
                lambda: VentanaCompras(
                    lambda: VentanaEmpleados(
                        lambda: VentanaVerClientes(
                            lambda: VentanaVentas(None)
                        )
                    )
                )
            )
        )
    )
    app.mainloop()

if __name__ == "__main__":
    main()
