import sqlite3
from tkinter import Tk, Label, Listbox, Scrollbar, Button, END, messagebox

class VentanaVerEmpleados(Tk):
    def __init__(self):
        super().__init__()
        self.title("Empleados Registrados - Abarrotes Wallis")
        self.geometry("600x400")

        Label(self, text="Listado de Empleados", font=("Arial", 14, "bold")).pack(pady=10)

        scrollbar = Scrollbar(self)
        scrollbar.pack(side="right", fill="y")

        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scrollbar.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)

        scrollbar.config(command=self.lista.yview)

        self.boton_actualizar = Button(self, text="Actualizar", command=self.cargar_empleados)
        self.boton_actualizar.pack(pady=5)

        self.cargar_empleados()

    def cargar_empleados(self):
        self.lista.delete(0, END)

        try:
            conexion = sqlite3.connect("willis.db")
            cursor = conexion.cursor()
            cursor.execute("""
                SELECT id_empleado, nombre, puesto, num_celular FROM Empleados
            """)
            registros = cursor.fetchall()
            conexion.close()

            if not registros:
                self.lista.insert(END, "No hay empleados registrados.")
                return

            header = f"{'ID':<15}{'Nombre':<25}{'Puesto':<20}{'Celular'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-"*70)

            for emp in registros:
                linea = f"{emp[0]:<15}{emp[1]:<25}{emp[2]:<20}{emp[3]}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

if __name__ == "__main__":
    app = VentanaVerEmpleados()
    app.mainloop()
