import sqlite3
from tkinter import Tk, Label, Listbox, Scrollbar, Button, END, messagebox

class VentanaVerClientes(Tk):
    def __init__(self):
        super().__init__()
        self.title("Clientes Registrados - Abarrotes Wallis")
        self.geometry("600x400")

        Label(self, text="Listado de Clientes", font=("Arial", 14, "bold")).pack(pady=10)

        scrollbar = Scrollbar(self)
        scrollbar.pack(side="right", fill="y")

        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scrollbar.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)

        scrollbar.config(command=self.lista.yview)

        self.boton_actualizar = Button(self, text="Actualizar", command=self.cargar_clientes)
        self.boton_actualizar.pack(pady=5)

        self.cargar_clientes()

    def cargar_clientes(self):
        self.lista.delete(0, END)

        try:
            conexion = sqlite3.connect("willis.db")
            cursor = conexion.cursor()
            cursor.execute("""
                SELECT id_cliente, nombre, direccion, telefono FROM Clientes
            """)
            registros = cursor.fetchall()
            conexion.close()

            if not registros:
                self.lista.insert(END, "No hay clientes registrados.")
                return

            header = f"{'ID':<15}{'Nombre':<25}{'Dirección':<25}{'Teléfono'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-" * 90)

            for cli in registros:
                telefono = cli[3] if cli[3] is not None else ""
                linea = f"{cli[0]:<15}{cli[1]:<25}{cli[2]:<25}{telefono}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

if __name__ == "__main__":
    app = VentanaVerClientes()
    app.mainloop()
