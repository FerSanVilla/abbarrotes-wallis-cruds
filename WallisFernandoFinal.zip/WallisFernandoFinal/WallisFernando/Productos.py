from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaProductos(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Productos - Abarrotes Wallis", siguiente_ventana)

        campos = [
            ("codigo", "Código"),
            ("nombre", "Nombre"),
            ("precio", "Precio"),
            ("costo", "Costo"),
            ("existencias", "Existencias"),
            ("id_categoria", "ID Categoría"),
            ("id_proveedor", "ID Proveedor"),
            ("id_unidad", "ID Unidad"),
            ("fecha_vencimiento", "Fecha Vencimiento")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self, text=texto)
            lbl.place(x=20, y=50 + i*40, width=120, height=20)
            self.entradas[clave] = Entry(self, bg="lightblue")
            self.entradas[clave].place(x=150, y=50 + i*40, width=200, height=20)

    def guardar_y_continuar(self):
        try:
            if not self.entradas["codigo"].get() or not self.entradas["nombre"].get():
                messagebox.showerror("Error", "Código y Nombre son obligatorios")
                return

            precio = self.entradas["precio"].get()
            costo = self.entradas["costo"].get()
            if precio:
                float(precio)
            if costo:
                float(costo)

            conexion = conectar()
            cursor = conexion.cursor()

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Productos (
                    codigo TEXT PRIMARY KEY,
                    nombre TEXT,
                    precio REAL,
                    costo REAL,
                    existencias INTEGER,
                    id_categoria TEXT,
                    id_proveedor TEXT,
                    id_unidad TEXT,
                    fecha_vencimiento TEXT
                )
            """)

            cursor.execute("""
                INSERT INTO Productos (codigo, nombre, precio, costo, existencias, id_categoria, id_proveedor, id_unidad, fecha_vencimiento)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                self.entradas["codigo"].get(),
                self.entradas["nombre"].get(),
                float(precio) if precio else None,
                float(costo) if costo else None,
                self.entradas["existencias"].get(),
                self.entradas["id_categoria"].get(),
                self.entradas["id_proveedor"].get(),
                self.entradas["id_unidad"].get(),
                self.entradas["fecha_vencimiento"].get()
            ))

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Producto guardado correctamente")
            self.abrir_siguiente_ventana()

        except ValueError:
            messagebox.showerror("Error", "Los campos numéricos deben tener valores válidos")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el producto:\n{e}")
