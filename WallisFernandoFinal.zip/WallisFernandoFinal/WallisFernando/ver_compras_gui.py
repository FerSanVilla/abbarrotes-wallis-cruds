import sqlite3
from tkinter import Tk, Label, Listbox, Scrollbar, Button, END, messagebox

class VentanaVerCompras(Tk):
    def __init__(self):
        super().__init__()
        self.title("Compras Registradas - Abarrotes Wallis")
        self.geometry("600x400")

        Label(self, text="Listado de Compras", font=("Arial", 14, "bold")).pack(pady=10)

        scrollbar = Scrollbar(self)
        scrollbar.pack(side="right", fill="y")

        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scrollbar.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)

        scrollbar.config(command=self.lista.yview)

        self.boton_actualizar = Button(self, text="Actualizar", command=self.cargar_compras)
        self.boton_actualizar.pack(pady=5)

        self.cargar_compras()

    def cargar_compras(self):
        self.lista.delete(0, END)

        try:
            conexion = sqlite3.connect("willis.db")
            cursor = conexion.cursor()
            cursor.execute("""
                SELECT id_compra, fecha, importe, id_proveedor FROM compras
            """)
            registros = cursor.fetchall()
            conexion.close()

            if not registros:
                self.lista.insert(END, "No hay compras registradas.")
                return

            header = f"{'ID Compra':<15}{'Fecha':<15}{'Importe':<15}{'ID Proveedor'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-"*65)

            for compra in registros:
                importe = f"{compra[2]:.2f}" if compra[2] is not None else "0.00"
                linea = f"{compra[0]:<15}{compra[1]:<15}{importe:<15}{compra[3]}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

if __name__ == "__main__":
    app = VentanaVerCompras()
    app.mainloop()
