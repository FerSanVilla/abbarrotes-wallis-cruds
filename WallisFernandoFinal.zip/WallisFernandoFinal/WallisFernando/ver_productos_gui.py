import sqlite3
from tkinter import Tk, Label, Listbox, Scrollbar, Button, END, messagebox

class VentanaVerProductos(Tk):
    def __init__(self):
        super().__init__()
        self.title("Productos Registrados - Abarrotes Wallis")
        self.geometry("800x400")

        Label(self, text="Listado de Productos", font=("Arial", 14, "bold")).pack(pady=10)

        scrollbar = Scrollbar(self)
        scrollbar.pack(side="right", fill="y")

        self.lista = Listbox(self, font=("Consolas", 10), yscrollcommand=scrollbar.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)

        scrollbar.config(command=self.lista.yview)

        self.boton_actualizar = Button(self, text="Actualizar", command=self.cargar_productos)
        self.boton_actualizar.pack(pady=5)

        self.cargar_productos()

    def cargar_productos(self):
        self.lista.delete(0, END)

        try:
            conexion = sqlite3.connect("willis.db")
            cursor = conexion.cursor()
            cursor.execute("""
                SELECT codigo, nombre, precio, costo, existencias, id_categoria, id_proveedor, id_unidad, fecha_vencimiento 
                FROM Productos
            """)
            registros = cursor.fetchall()
            conexion.close()

            if not registros:
                self.lista.insert(END, "No hay productos registrados.")
                return

            header = (f"{'Código':<10}{'Nombre':<20}{'Precio':<10}{'Costo':<10}"
                      f"{'Existencias':<12}{'ID Cat.':<10}{'ID Prov.':<10}{'ID Unidad':<10}{'Fecha Venc.'}")
            self.lista.insert(END, header)
            self.lista.insert(END, "-" * 100)

            for prod in registros:
                linea = (f"{prod[0]:<10}{prod[1]:<20}{prod[2]:<10.2f}{prod[3]:<10.2f}"
                         f"{prod[4]:<12}{prod[5]:<10}{prod[6]:<10}{prod[7]:<10}{prod[8]}")
                self.lista.insert(END, linea)

        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

if __name__ == "__main__":
    app = VentanaVerProductos()
    app.mainloop()
