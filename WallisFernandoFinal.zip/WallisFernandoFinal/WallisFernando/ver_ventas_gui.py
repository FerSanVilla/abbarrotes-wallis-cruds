import sqlite3
from tkinter import Tk, Label, Listbox, Scrollbar, Button, END, messagebox

class VentanaVerVentas(Tk):
    def __init__(self):
        super().__init__()
        self.title("Ventas Registradas - Abarrotes Wallis")
        self.geometry("700x400")

        Label(self, text="Listado de Ventas", font=("Arial", 14, "bold")).pack(pady=10)

        scrollbar = Scrollbar(self)
        scrollbar.pack(side="right", fill="y")

        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scrollbar.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)

        scrollbar.config(command=self.lista.yview)

        self.boton_actualizar = Button(self, text="Actualizar", command=self.cargar_ventas)
        self.boton_actualizar.pack(pady=5)

        self.cargar_ventas()

    def cargar_ventas(self):
        self.lista.delete(0, END)

        try:
            conexion = sqlite3.connect("willis.db")
            cursor = conexion.cursor()
            cursor.execute("""
                SELECT id_venta, fecha, importe, id_cliente, id_empleado FROM Ventas
            """)
            registros = cursor.fetchall()
            conexion.close()

            if not registros:
                self.lista.insert(END, "No hay ventas registradas.")
                return

            header = f"{'ID Venta':<15}{'Fecha':<15}{'Importe':<15}{'ID Cliente':<15}{'ID Empleado'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-"*80)

            for venta in registros:
                linea = f"{venta[0]:<15}{venta[1]:<15}{venta[2]:<15}{venta[3]:<15}{venta[4]}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

if __name__ == "__main__":
    app = VentanaVerVentas()
    app.mainloop()
