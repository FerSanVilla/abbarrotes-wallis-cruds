import sqlite3
from tkinter import Tk, Label, Listbox, Scrollbar, END, messagebox

class VentanaVerCategorias(Tk):
    def __init__(self):
        super().__init__()
        self.title("Categorías Registradas - Abarrotes Wallis")
        self.geometry("500x400")

        Label(self, text="Listado de Categorías", font=("Arial", 14, "bold")).pack(pady=10)

        scrollbar = Scrollbar(self)
        scrollbar.pack(side="right", fill="y")

        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scrollbar.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)

        scrollbar.config(command=self.lista.yview)

        self.cargar_categorias()

    def cargar_categorias(self):
        self.lista.delete(0, END)

        try:
            conexion = sqlite3.connect("willis.db")
            cursor = conexion.cursor()
            cursor.execute("SELECT id_categoria, nombre, descripcion FROM Categorias")
            registros = cursor.fetchall()
            conexion.close()

            if not registros:
                self.lista.insert(END, "No hay categorías registradas.")
                return

            header = f"{'ID':<5}{'Nombre':<20}{'Descripción'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-" * 60)

            for cat in registros:
                linea = f"{cat[0]:<5}{cat[1]:<20}{cat[2]}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

if __name__ == "__main__":
    app = VentanaVerCategorias()
    app.mainloop()
