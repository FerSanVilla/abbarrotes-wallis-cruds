from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaVentas(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Ventas - Abarrotes Wallis", siguiente_ventana)

        campos = [
            ("id_venta", "ID Venta"),
            ("fecha", "Fecha"),
            ("importe", "Importe"),
            ("id_cliente", "ID Cliente"),
            ("id_empleado", "ID Empleado")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self, text=texto)
            lbl.place(x=20, y=50 + i*40, width=100, height=20)
            self.entradas[clave] = Entry(self, bg="plum")
            self.entradas[clave].place(x=130, y=50 + i*40, width=200, height=20)

    def guardar_y_continuar(self):
        try:
            if not self.entradas["id_venta"].get() or not self.entradas["fecha"].get():
                messagebox.showerror("Error", "ID Venta y Fecha son obligatorios")
                return

            importe = self.entradas["importe"].get()
            if importe:
                float(importe)

            conexion = conectar()
            cursor = conexion.cursor()

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Ventas (
                    id_venta TEXT PRIMARY KEY,
                    fecha TEXT,
                    importe REAL,
                    id_cliente TEXT,
                    id_empleado TEXT
                )
            """)

            cursor.execute("""
                INSERT INTO Ventas (id_venta, fecha, importe, id_cliente, id_empleado)
                VALUES (?, ?, ?, ?, ?)
            """, (
                self.entradas["id_venta"].get(),
                self.entradas["fecha"].get(),
                float(importe) if importe else None,
                self.entradas["id_cliente"].get(),
                self.entradas["id_empleado"].get()
            ))

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Venta registrada correctamente")
            self.abrir_siguiente_ventana()

        except ValueError:
            messagebox.showerror("Error", "El importe debe ser un número válido")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar la venta:\n{e}")

