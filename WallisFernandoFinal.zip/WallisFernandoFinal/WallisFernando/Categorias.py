from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar  # reemplaza sqlite3 por conexión centralizada

class VentanaCategorias(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Categorías - Abarrotes Wallis", siguiente_ventana)

        Label(self.frame, text="Nombre:").grid(row=0, column=0, padx=10, pady=5)
        self.entradas["nombre"] = Entry(self.frame)
        self.entradas["nombre"].grid(row=0, column=1, padx=10, pady=5)

        Label(self.frame, text="Descripción:").grid(row=1, column=0, padx=10, pady=5)
        self.entradas["descripcion"] = Entry(self.frame)
        self.entradas["descripcion"].grid(row=1, column=1, padx=10, pady=5)

    def guardar_y_continuar(self):
        nombre = self.entradas["nombre"].get()
        descripcion = self.entradas["descripcion"].get()

        if not nombre:
            messagebox.showerror("Error", "El nombre es obligatorio.")
            return

        try:
            conexion = conectar()
            cursor = conexion.cursor()

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Categorias (
                    id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT,
                    descripcion TEXT
                )
            """)

            cursor.execute("INSERT INTO Categorias (nombre, descripcion) VALUES (?, ?)", (nombre, descripcion))

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Categoría guardada correctamente.")
            self.abrir_siguiente_ventana()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar:\n{e}")

