from tkinter import Label, Listbox, Scrollbar, Button, END, messagebox, Tk
from base import VentanaBase
from conexion_bd import conectar

class VentanaVerClientes(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Clientes Registrados - Abarrotes Wallis", siguiente_ventana)
        self.geometry("600x400")

        Label(self, text="Listado de Clientes", font=("Arial", 14, "bold")).pack(pady=10)

        scrollbar = Scrollbar(self)
        scrollbar.pack(side="right", fill="y")

        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scrollbar.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)

        scrollbar.config(command=self.lista.yview)

        self.boton_actualizar = Button(self, text="Actualizar", command=self.cargar_clientes)
        self.boton_actualizar.pack(pady=5)

        self.cargar_clientes()

    def cargar_clientes(self):
        self.lista.delete(0, END)

        try:
            conexion = conectar()
            cursor = conexion.cursor()
            cursor.execute("""
                SELECT id_cliente, nombre, telefono, direccion FROM Clientes
            """)
            registros = cursor.fetchall()
            conexion.close()

            if not registros:
                self.lista.insert(END, "No hay clientes registrados.")
                return

            header = f"{'ID':<15}{'Nombre':<25}{'Teléfono':<20}{'Dirección'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-" * 80)

            for cli in registros:
                telefono = cli[2] if cli[2] is not None else ""
                direccion = cli[3] if cli[3] is not None else ""
                linea = f"{cli[0]:<15}{cli[1]:<25}{telefono:<20}{direccion}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")
